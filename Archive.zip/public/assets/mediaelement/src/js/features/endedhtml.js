'use strict';


Object.assign(MediaElementPlayer.prototype, {
	buildendedhtml: function (player, controls, layers, media)  {
		if (!player.isVideo) {
			return;
		}

		// add postroll
	}
});
	
