### TODO

#### Features to be implemented

*All items listed in https://github.com/johndyer/mediaelement/labels/Feature*

**NOTE** Please make sure any features are labeled with `Feature` to make them available with the link above.


#### Known issues

*Known issues to be resolved listed in https://github.com/johndyer/mediaelement/labels/Bug*

**NOTE** Please make sure any bugs are labeled with `Bug` to make them available with the link above.